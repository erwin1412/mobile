<?php

$host = "localhost";
$username = "sisd6227_kita_collection";
$password = "si19412416";
$db = "sisd6227_db_kita_collection";

$connect = new mysqli($host,$username,$password,$db);

?>