<?php
include '../connection.php';

// $sql =  "SELECT shoes .*,ukuran FROM `shoes` LEFT JOIN (SELECT id_shoes, GROUP_CONCAT(sizes SEPARATOR ', ') AS ukuran FROM ukuran WHERE terbeli=0 GROUP BY id_shoes) Testing ON shoes.id_shoes = Testing.id_shoes";

$sql = "SELECT shoes .*,ukuran FROM `shoes` LEFT JOIN (SELECT id_shoes, GROUP_CONCAT(sizes SEPARATOR ', ') AS ukuran FROM ukuran WHERE terbeli=0 GROUP BY id_shoes) Testing ON shoes.id_shoes = Testing.id_shoes having ukuran is not null order by shoes.id_shoes";


$result = $connect->query($sql);

if($result->num_rows > 0) {    
    $data = array();
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode(array(
        "success"=>true,
        "data"=> $data,
    ));
} else {
    echo json_encode(array(
        "success"=>false,
    ));
}