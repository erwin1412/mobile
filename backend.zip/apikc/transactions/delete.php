<?php
include '../connection.php';

$idtransactions = $_POST['id_transactions'];
$image = $_POST['image'];

$sql = "DELETE FROM transactions
        WHERE
        id_transactions = '$idtransactions'
        ";

$result = $connect->query($sql);

if($result) {
    // delete image
    unlink("../images/".$bukti);

    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}