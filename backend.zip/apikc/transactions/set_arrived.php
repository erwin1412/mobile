<?php
include '../connection.php';

$idtransactions = $_POST['id_transactions'];
$arrived = $_POST['arrived'];
$arrived = "Menunggu Konfirmasi";
$sql = "UPDATE transactions
        SET
        arrived = 'Arrived'
        WHERE
        id_transactions = '$idtransactions'
        ";

$result = $connect->query($sql);

if($result) {
    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}