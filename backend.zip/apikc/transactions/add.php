<?php
include '../connection.php';

$idUser = $_POST['id_user'];
$listShop = $_POST['list_shop'];
$ekspedisi = $_POST['ekspedisi'];
$pembayaran = $_POST['pembayaran'];
$alamat = $_POST['alamat'];
$total = $_POST['total'];
$bukti = $_POST['bukti'];
$imageBase64 = $_POST['image_file'];

$sql = "INSERT INTO transactions
        SET
        id_user = '$idUser',
        list_shop = '$listShop',
        ekspedisi = '$ekspedisi',
        pembayaran = '$pembayaran',
        alamat = '$alamat',
        total = '$total',
        bukti = '$bukti'
        ";

$result = $connect->query($sql);

if($result) {
    // save image
    $imageFile = base64_decode($imageBase64);
    file_put_contents("../images/".$bukti, $imageFile);
    
$substr= strval($listShop);


$newData = explode("||",$substr);


foreach ($newData as $data) {
    $decodedData = json_decode($data, true);

    // tampung data ['yang ada di list_shop']
    $idBarang = $decodedData["id_shoes"];
    $sizes = $decodedData["size"];
    $sql ="UPDATE ukuran SET terbeli=true WHERE id_shoes=$idBarang AND sizes=$sizes";
    $result = $connect->query($sql);
}


    
    
    
    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}