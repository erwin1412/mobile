<?php
include '../connection.php';

$name = $_POST['name'];
$email = $_POST['email'];
$password = md5($_POST['password']);
$phone = $_POST['phone'];

$sql =  "INSERT INTO user SET
        name = '$name',
        email = '$email',
        password = '$password',
        phone = '$phone'
        ";

$result = $connect->query($sql);

if($result) {
    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}