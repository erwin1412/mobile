<?php
include '../connection.php';

$idKeranjang = $_POST['id_keranjang'];

$sql = "DELETE FROM keranjang
        WHERE
        id_keranjang = '$idKeranjang'
        ";

$result = $connect->query($sql);
if($result) {
    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}