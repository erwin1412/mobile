<?php
include '../connection.php';

$idKeranjang = $_POST['id_keranjang'];
$quantity = $_POST['quantity'];

$sql = "UPDATE keranjang
        SET
        quantity = '$quantity'
        WHERE
        id_keranjang = '$idKeranjang'
        ";

$result = $connect->query($sql);

if($result) {
    echo json_encode(array("success"=>true));
} else {
    echo json_encode(array("success"=>false));
}